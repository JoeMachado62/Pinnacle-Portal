<div class="hf-small-margin">
	<p><strong><?php _e( 'Looking for help?', 'html-forms' ); ?></strong>
		<?php echo sprintf( __('Check out the <a href="%s">HTML Forms Knowledge Base</a>', 'html-forms' ), 'https://htmlformsplugin.com/kb/#utm_source=wp-plugin&utm_medium=html-forms&utm_campaign=admin-footer' ); ?>.</p>
</div>
