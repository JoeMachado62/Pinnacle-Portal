<?php
if (!defined("ABSPATH")) {
    exit();
}
?>
<div class="page__block automatic-redirects-block">
    <p class="page__paragraph"><?php _e( "All the options on the other tabs didn't touch the source URL structures, but only applied redirects. On this tab you can pick options which will change the source URL structure too.", "redirect-redirection" ); ?></p><br>
    <p class="page__paragraph"><?php _e( "This is currently in progress – stay tuned!", "redirect-redirection" ); ?></p>
</div>