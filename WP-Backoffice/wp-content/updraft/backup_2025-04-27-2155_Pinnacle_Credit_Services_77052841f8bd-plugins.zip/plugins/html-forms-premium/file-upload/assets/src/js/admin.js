html_forms.FieldBuilder.registerField( 'file', 'File Upload', [ "label", "accept", "required", "add-to-form" ]);
