# Roadmap

#### Must

- Validate type of uploaded file
- Validate filename of uploaded file.

#### Should

- Protect uploads directory

#### Could


#### Would
