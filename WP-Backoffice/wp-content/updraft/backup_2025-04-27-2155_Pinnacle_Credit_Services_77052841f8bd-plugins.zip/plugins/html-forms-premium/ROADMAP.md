## Must

## Should
- Data management: sanitize new column name when renaming column.
- Form scheduler: Schedule form (as in Gravity Forms)
- Data search: search data fields for string
- Action: Subscribe to MailChimp

## Could
- File uploads: Add `File` class
- Form limiter: Limit form submissions (as in  Gravity Forms)
- Form locker: Require user to be logged in (w/ message for guests) (as in Gravity Forms)
- Option to process form actions in background.

## Would
