<?php

require __DIR__ . '/src/Action.php';

$action = new HTML_Forms\Actions\Webhook();
$action->hook();
