<?php return array('dependencies' => array(), 'version' => '0eec8e66880717bf7da1');
